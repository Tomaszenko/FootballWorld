create FUNCTION totval(nrzam t_z_ksiazka.id_zam%type)
  RETURN t_ksiazka.cena%type
IS
  vsumazam t_ksiazka.cena%type;
BEGIN
  SELECT SUM(tk.cena*tzk.ilosc) INTO vsumazam
  FROM t_z_ksiazka tzk INNER JOIN t_ksiazka tk ON tzk.isbn=tk.isbn
  WHERE tzk.isbn=nrzam;
  
  RETURN vsumazam;
END;