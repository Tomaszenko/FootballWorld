create FUNCTION funkcja_2_3(orderno orders.order#%type)
RETURN number
AS
  v_result number;
BEGIN
  SELECT SUM(bk.retail*oi.quantity) INTO v_result
  FROM orderitems oi INNER JOIN books bk ON bk.isbn=oi.isbn
  WHERE oi.order#=orderno;
  
  RETURN v_result;
  
  EXCEPTION
  WHEN NO_DATA_FOUND
  THEN RETURN 0;
END;