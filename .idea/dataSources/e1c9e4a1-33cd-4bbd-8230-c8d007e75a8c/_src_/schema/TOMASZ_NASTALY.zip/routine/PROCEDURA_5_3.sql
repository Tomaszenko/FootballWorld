create PROCEDURE procedura_5_3
AS
  CURSOR curcustomers IS
  SELECT * FROM customers_copy;
  
  TYPE customersArray IS TABLE OF customers_copy%rowtype INDEX BY pls_integer;
  customersBulk customersArray;
  t1 number;
  t2 number;
  i number;
BEGIN
  t1:=dbms_utility.get_time();
  OPEN curcustomers;
  LOOP
    FETCH curcustomers BULK COLLECT INTO customersBulk
    LIMIT 500;
    EXIT WHEN customersBulk.count<500;
  END LOOP;
  CLOSE curcustomers;
  dbms_output.put_line('W kolekcji mamy '||customersBulk.last||' rekordów');
  t2:=dbms_utility.get_time();
  
  IF customersBulk.first is NOT NULL THEN
    i:=customersBulk.first;
    WHILE (i IS NOT NULL) 
    LOOP
      dbms_output.put_line(customersBulk(i).lastname||' '||customersBulk(i).address);
      i:=customersBulk.next(i);
    END LOOP;
  END IF;
  
  dbms_output.put_line(to_char((t2-t1)*10)||' ms');
  dbms_output.put_line('W kolekcji mamy '||customersBulk.count||' rekordów');
END;