create PROCEDURE procedura_5_4
AS
  CURSOR curcustomers IS
  SELECT * FROM customers_copy;
  
  TYPE customersArray IS TABLE OF customers_copy%rowtype INDEX BY pls_integer;
  customersBulk customersArray;
  t1 number;
  t2 number;
  t3 number;
  t4 number;
  i number;
BEGIN
  t1:=dbms_utility.get_time();
  OPEN curcustomers;
    FETCH curcustomers BULK COLLECT INTO customersBulk;
  CLOSE curcustomers;
  t2:=dbms_utility.get_time();

  t3:=dbms_utility.get_time();
--  FORALL rec IN customersBulk.first..customersBulk.last
  FOR i IN customersBulk.first..customersBulk.last LOOP
    INSERT INTO customers_copy VALUES customersBulk(i);
  END LOOP;
  t4:=dbms_utility.get_time();  
    
--  IF customersBulk.first is NOT NULL THEN
--    i:=customersBulk.first;
--    WHILE (i IS NOT NULL) 
--    LOOP
--      dbms_output.put_line(customersBulk(i).lastname||' '||customersBulk(i).address);
--      i:=customersBulk.next(i);
--    END LOOP;
--  END IF;
  
  dbms_output.put_line('Czas ladowania do tablicy asocjacyjnej z tabeli: '||to_char((t2-t1)*10)||' ms');
  dbms_output.put_line('Czas ladowania do tabeli z tablicy asocjacyjnej: '||to_char((t4-t3)*10)||' ms');
  dbms_output.put_line('W kolekcji mamy '||customersBulk.count||' rekordów');
END;