create PROCEDURE procedura_2_2(tytul books.title%type)
AS
BEGIN
  UPDATE books_copy
  SET retail=0.95*retail
  WHERE title=tytul;
  
  IF SQL%ROWCOUNT=0 THEN
    INSERT INTO books_copy (title) VALUES(tytul);
  END IF;
  
  DELETE FROM bookauthor ba
  WHERE ba.isbn IN (SELECT ba.isbn FROM bookauthor ba GROUP BY ba.isbn HAVING COUNT(ba.authorid)>1);
  
  DELETE FROM books bk
  WHERE bk.isbn IN (SELECT ba.isbn FROM bookauthor ba GROUP BY ba.ISBN HAVING COUNT(ba.authorid)>1);
  
  IF SQL%ROWCOUNT>0 THEN
    dbms_output.put_line('Usunięto '||SQL%ROWCOUNT||' wierszy');
  END IF;
END;