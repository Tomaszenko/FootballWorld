create PROCEDURE procedura_2_5
AS
v_tytul books.title%type;
v_ilosc orderitems.quantity%type;
BEGIN
  INSERT INTO komunikat(kol1,kol3)
  SELECT bk.title, sum(oi.quantity)
  FROM books bk INNER JOIN orderitems oi ON bk.isbn=oi.isbn
  GROUP BY bk.title
  HAVING sum(oi.quantity)=(SELECT max(sum(oi1.quantity))
                           FROM books bk1 INNER JOIN orderitems oi1 ON bk1.isbn=oi1.isbn
                           GROUP BY bk1.title);
END;