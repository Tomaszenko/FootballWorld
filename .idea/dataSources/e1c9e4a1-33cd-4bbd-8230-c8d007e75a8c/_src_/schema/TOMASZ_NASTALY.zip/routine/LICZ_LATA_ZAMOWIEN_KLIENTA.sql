create FUNCTION licz_lata_zamowien_klienta(p_customer# customers.customer#%type)
RETURN NUMBER IS
v_zmienna NUMBER;
BEGIN
SELECT COUNT(DISTINCT EXTRACT (year FROM orderdate)) into v_zmienna
FROM orders
WHERE customer# = p_customer#;
RETURN v_zmienna;
END;