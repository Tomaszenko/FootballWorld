create PROCEDURE czyszczenie
IS
  CURSOR mycols IS
  SELECT column_name
  FROM user_tab_columns utc
  WHERE lower(utc.table_name)='komunikat';
  l_query VARCHAR2(100);
  niepierwszy BOOLEAN;
BEGIN
    l_query := 'DELETE FROM komunikat WHERE ';
    niepierwszy := FALSE;
    FOR mycol IN mycols LOOP
      if niepierwszy=true then
        l_query := l_query || 'OR ';
      else
        niepierwszy := true;
      end if;
      l_query := l_query || mycol.column_name || ' IS NULL ';
      
--      IF not_null_row_count=0 THEN 
--         l_query := 'ALTER TABLE PreparedDocumentFeaturesValues DROP COLUMN ' || columnItem.column_name;
--         EXECUTE IMMEDIATE l_query;
--      if mycol is null then
--        DELETE FROM komunikat WHERE CURRENT OF cur;
--        break;
--    END LOOP;
  END LOOP;
  EXECUTE IMMEDIATE l_query;
END;