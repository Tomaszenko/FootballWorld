create PROCEDURE procedura_6_5(table_name varchar2)
AS
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE :tab'
  USING table_name;
END;