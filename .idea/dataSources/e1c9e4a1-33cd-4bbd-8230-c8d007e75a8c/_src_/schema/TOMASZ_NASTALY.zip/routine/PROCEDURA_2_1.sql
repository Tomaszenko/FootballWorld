create PROCEDURE procedura_2_1
AS
  CURSOR notOrdered IS
    SELECT isbn FROM books_copy bk WHERE NOT EXISTS 
                          (SELECT oi.isbn FROM orderitems oi WHERE oi.isbn=bk.isbn)
    FOR UPDATE;
  
  CURSOR bestsellers IS
    SELECT * FROM books_copy bk WHERE bk.isbn IN (SELECT oi.isbn FROM orderitems oi GROUP BY oi.isbn HAVING COUNT(oi.order#)>1)
    FOR UPDATE;
BEGIN
  FOR i IN notOrdered LOOP
    DELETE FROM books_copy
    WHERE CURRENT OF notOrdered;
  END LOOP;
  
  FOR i IN bestsellers LOOP
    UPDATE books_copy
    SET retail=1.1*retail
    WHERE CURRENT OF bestsellers;
  END LOOP;
END;