create PROCEDURE procedura_2_6(prog orderitems.quantity%type)
AS
BEGIN
  INSERT INTO komunikat(kol1,kol2,kol3)
  SELECT bk.title, COUNT(oi.order#),NVL(SUM(oi.quantity),0)
  FROM books bk LEFT JOIN orderitems oi ON bk.isbn=oi.isbn
  GROUP BY bk.title
  HAVING COUNT(oi.order#)<prog;
END;