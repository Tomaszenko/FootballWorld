create PROCEDURE usuwacz(nazwa varchar2)
AS
  table_not_exists EXCEPTION;
  PRAGMA EXCEPTION_INIT(table_not_exists,-942);
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE '||nazwa;
  EXCEPTION
  WHEN table_not_exists
  THEN dbms_output.put_line('Kod bledu: '||SQLCODE||'\n'||SQLERRM(SQLCODE));
END;