create PROCEDURE procedura_6_2(p_id t_sprzedaz.id%type,
p_stan t_sprzedaz.stan%type, p_miejscowosc t_sprzedaz.miejscowosc%type,
p_sprzedane t_sprzedaz.sprzedane%type)
AS
BEGIN
EXECUTE IMMEDIATE 'INSERT INTO t_sprzedaz(id,stan,miejscowosc,sprzedane) VALUES(:a,:b,:c,:d)'
USING p_id,p_stan,p_miejscowosc,p_sprzedane;
END;