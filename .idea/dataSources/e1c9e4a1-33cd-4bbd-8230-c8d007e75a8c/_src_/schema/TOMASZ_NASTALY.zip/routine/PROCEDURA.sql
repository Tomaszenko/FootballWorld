create PROCEDURE procedura(id number, stan varchar2(2), miejscowosc varchar2(30), sprzedane number)
IS
BEGIN
  INSERT INTO t_sprzedaz VALUES(id,stan,miejscowosc,sprzedane);
END;