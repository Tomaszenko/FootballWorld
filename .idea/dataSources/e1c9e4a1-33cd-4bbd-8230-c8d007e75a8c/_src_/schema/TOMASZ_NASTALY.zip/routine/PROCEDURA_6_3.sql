create PROCEDURE procedura_6_3
AS
CURSOR cur IS 
SELECT ord.shipstate shipstate, ord.shipcity shipcity, SUM(oi.quantity) numBooks
FROM orders ord INNER JOIN orderitems oi ON ord.order#=oi.order#
GROUP BY ord.shipstate,ord.shipcity;
BEGIN
  FOR i IN cur LOOP
    EXECUTE IMMEDIATE 'INSERT INTO t_sprzedaz(id,stan,miejscowosc,sprzedane) VALUES(:a,:b,:c,:d)'
    USING sekwencja_6_3.nextval,i.shipstate,i.shipcity,i.numBooks;
  END LOOP;
END;