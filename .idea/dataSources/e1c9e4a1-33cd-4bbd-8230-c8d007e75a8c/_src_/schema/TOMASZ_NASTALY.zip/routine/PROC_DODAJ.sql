create PROCEDURE proc_dodaj(id number, stan varchar2, miejscowosc varchar2, sprzedane number)
AS
BEGIN
  EXECUTE IMMEDIATE 'INSERT INTO t_sprzedaz VALUES(:a,:b,:c,:d)' 
  USING id,stan,miejscowosc,sprzedane;
END proc_dodaj;