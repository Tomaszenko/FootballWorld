create PROCEDURE procedura_3_4(publname publisher.name%type)
AS
  v_name varchar2(512);
  v_count number;
  v_msg varchar2(512);
  v_code number;
BEGIN
    SELECT pub.name, COUNT(DISTINCT bk.title) INTO v_name,v_count
    FROM publisher pub LEFT JOIN books bk ON pub.pubid=bk.pubid
    WHERE pub.name=publname
    GROUP BY pub.pubid, pub.name;
    
    INSERT INTO komunikat(kol1,kol3) VALUES(v_name,v_count);
    
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX
      THEN 
        v_code:=SQLCODE;
        v_msg:=SQLERRM;
          INSERT INTO komunikat (kol1,kol3) VALUES(v_msg,v_code);
      WHEN NO_DATA_FOUND
      THEN 
        v_code:=SQLCODE;
        v_msg:=SQLERRM;
          INSERT INTO komunikat (kol1,kol3) VALUES(v_msg,v_code);
      WHEN TOO_MANY_ROWS
      THEN 
        v_code:=SQLCODE;
        v_msg:=SQLERRM;
          INSERT INTO komunikat (kol1,kol3) VALUES(v_msg,v_code);
      WHEN OTHERS
      THEN 
        v_code:=SQLCODE;
        v_msg:=SQLERRM;
          INSERT INTO komunikat (kol1,kol3) VALUES(v_msg,v_code);
END;