create PROCEDURE procedura_5_1(factor number)
AS
  TYPE coll_customers IS TABLE OF customers%rowtype;
  CURSOR customer_cursor IS
  SELECT * FROM customers;  
BEGIN
  FOR i IN 1..factor LOOP
    FOR customer IN customer_cursor LOOP
      INSERT INTO customers_copy VALUES(customer.customer#,customer.lastname,customer.firstname,customer.address,customer.city,customer.state,customer.zip,customer.referred);
    END LOOP;
  END LOOP;
END;