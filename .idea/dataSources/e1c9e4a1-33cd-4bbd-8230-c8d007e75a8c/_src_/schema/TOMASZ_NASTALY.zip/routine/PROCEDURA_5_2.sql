create PROCEDURE procedura_5_2
AS
  TYPE coll_customers IS TABLE OF customers_copy%rowtype INDEX BY pls_integer;
  collected_customers coll_customers;
  CURSOR customer_cursor IS
  SELECT * FROM customers_copy;  
  it number;
  t1 number;
  t2 number;
BEGIN
  it:=0;
  t1:=dbms_utility.get_time();
  FOR i IN customer_cursor LOOP
    collected_customers(it):=i;
    it:=it+1;
  END LOOP;
  t2:=dbms_utility.get_time();
  
  dbms_output.put_line(to_char((t2-t1)*10)||' ms');
  dbms_output.put_line(collected_customers.count);
END;