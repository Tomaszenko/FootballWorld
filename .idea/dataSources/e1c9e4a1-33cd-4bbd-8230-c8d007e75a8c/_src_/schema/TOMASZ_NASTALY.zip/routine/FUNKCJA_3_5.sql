create FUNCTION funkcja_3_5
RETURN number
AS
  v_klientid CUSTOMERS.CUSTOMER#%type;
BEGIN
  SELECT customer# INTO v_klientid
  FROM orders
  GROUP BY customer#
  HAVING COUNT(order#)=1;
  
  EXCEPTION
    WHEN TOO_MANY_ROWS
    THEN RAISE;
    WHEN NO_DATA_FOUND
    THEN RAISE;
END;