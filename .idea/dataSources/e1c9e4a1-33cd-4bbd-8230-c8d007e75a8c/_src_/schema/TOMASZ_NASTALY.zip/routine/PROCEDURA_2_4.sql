create PROCEDURE procedura_2_4
AS
command varchar2(1000);
CURSOR colstab IS
SELECT column_name FROM user_tab_cols
WHERE table_name ='KOMUNIKAT';
firstCol boolean;
BEGIN
  firstCol:=true;
  command:='DELETE FROM komunikat WHERE ';
  FOR colum IN colstab LOOP
    IF NOT firstCol THEN
      command:= command || ' OR ';
    ELSE
      firstCol:=false;
    END IF;
    dbms_output.put_line(command);
    command:= command || colum.column_name || ' IS NULL';
  END LOOP;
  
  EXECUTE IMMEDIATE command;
END procedura_2_4;