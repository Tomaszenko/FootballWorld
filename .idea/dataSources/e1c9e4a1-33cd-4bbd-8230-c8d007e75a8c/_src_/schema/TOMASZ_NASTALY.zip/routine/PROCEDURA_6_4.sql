create PROCEDURE procedura_6_4
AS
  TYPE assoc_table IS TABLE OF t_sprzedaz%rowtype;
  tablica assoc_table;
  dyncur sys_REFCURSOR;
BEGIN
  open dyncur for 'SELECT * FROM t_sprzedaz';
  FETCH dyncur BULK COLLECT INTO tablica;
  CLOSE dyncur;
  
  FOR i IN tablica.first..tablica.last LOOP
    dbms_output.put_line(tablica(i).id||' '||tablica(i).stan||' '||
      tablica(i).miejscowosc||' '||tablica(i).sprzedane);
  END LOOP;
END;