create trigger TRIG_PIELEGNIARKA_TN
	before insert
	on PIELEGNIARKA
	for each row
BEGIN
  :NEW.id_pielegniarki:=seq_pielegniarka.nextval;
END;