create trigger TRIG_W_TURNUS_TN
	before insert
	on W_TURNUS
	for each row
BEGIN
  :NEW.id_w_turnusu:=seq_w_turnus.nextval;
END;