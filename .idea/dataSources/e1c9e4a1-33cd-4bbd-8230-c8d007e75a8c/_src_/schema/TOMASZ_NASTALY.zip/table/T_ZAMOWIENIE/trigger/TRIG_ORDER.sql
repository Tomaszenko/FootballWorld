create trigger TRIG_ORDER
	before update
	on T_ZAMOWIENIE
	for each row
BEGIN
  UPDATE t_z_ksiazka
  SET data_wys=sysdate
  WHERE id_zam=:NEW.id_zam;
END;