create trigger TRIG_TURNUS_TN
	before insert
	on TURNUS
	for each row
BEGIN
  :NEW.id_turnusu:=seq_turnus.nextval;
END;