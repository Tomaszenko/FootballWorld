create trigger TRIG_KSIADZ_TN
	before insert
	on KSIADZ
	for each row
BEGIN
  :NEW.id_ksiedza:=seq_ksiadz.nextval;
END;