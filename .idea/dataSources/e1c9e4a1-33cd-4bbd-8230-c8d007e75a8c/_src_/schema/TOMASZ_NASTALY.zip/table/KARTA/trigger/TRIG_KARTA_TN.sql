create trigger TRIG_KARTA_TN
	before insert
	on KARTA
	for each row
BEGIN
  :NEW.id_karty:=seq_karta.nextval;
END;