create trigger TRIG_PODOPIECZNY_TN
	before insert
	on PODOPIECZNY
	for each row
BEGIN
  :NEW.id_podopiecznego:=seq_podopieczny.nextval;
END;