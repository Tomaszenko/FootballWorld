create trigger TRIG_PLACOWKA_TN
	before insert
	on PLACOWKA
	for each row
BEGIN
  :NEW.id_placowki:=seq_placowka.nextval;
END;