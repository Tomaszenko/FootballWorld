create trigger TRIG_P_SCHORZENIE_TN
	before insert
	on P_SCHORZENIE
	for each row
BEGIN
  :NEW.id_sch_podop:=seq_p_schorzenie.nextval;
END;