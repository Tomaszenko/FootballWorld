create trigger TRIG_WOLONTARIUSZ_TN
	before insert
	on WOLONTARIUSZ
	for each row
BEGIN
  :NEW.id_wolontariusza:=seq_wolontariusz.nextval;
END;