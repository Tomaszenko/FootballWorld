create trigger TRIG_KSIAZKI
	before update of CENA
	on T_KSIAZKA
	for each row
BEGIN
  dbms_output.put_line('Za wysoka podwyżka książki'||:new.tytul);
  :new.cena:=1.1*:old.cena;
END;