create trigger TRIG_DYREKTOR_TN
	before insert
	on DYREKTOR
	for each row
BEGIN
  :NEW.id_dyrektora:=seq_dyrektor.nextval;
END;