create trigger TRIG_KOORDYNATOR_TN
	before insert
	on KOORDYNATOR
	for each row
BEGIN
  :NEW.id_koordynatora:=seq_koordynator.nextval;
END;