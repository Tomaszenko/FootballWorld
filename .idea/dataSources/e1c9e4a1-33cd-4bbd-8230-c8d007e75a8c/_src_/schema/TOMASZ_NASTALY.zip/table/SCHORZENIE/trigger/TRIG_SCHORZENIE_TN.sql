create trigger TRIG_SCHORZENIE_TN
	before insert
	on SCHORZENIE
	for each row
BEGIN
  :NEW.id_schorzenia:=seq_schorzenie.nextval;
END;