create trigger TRIG_LEK_TN
	before insert
	on LEK
	for each row
BEGIN
  :NEW.id_leku:=seq_lek.nextval;
END;