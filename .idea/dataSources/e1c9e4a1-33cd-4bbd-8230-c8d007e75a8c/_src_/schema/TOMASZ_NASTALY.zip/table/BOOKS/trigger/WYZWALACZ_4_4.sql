create trigger WYZWALACZ_4_4
	before update of RETAIL
	on BOOKS
	for each row
BEGIN
  :new.retail:=:old.retail;
  dbms_output.put_line('Podwyżka książki '||:new.title||' zbyt wysoka');
END;