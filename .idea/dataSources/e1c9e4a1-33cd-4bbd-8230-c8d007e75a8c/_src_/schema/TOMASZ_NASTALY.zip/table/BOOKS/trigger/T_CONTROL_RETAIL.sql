create trigger T_CONTROL_RETAIL
	before update of RETAIL
	on BOOKS
	for each row
BEGIN
  :NEW.retail:=1.1*:OLD.retail;
  dbms_output.put_line('Cena za wysoka dla książki:'|| :OLD.title);
END;