create trigger TRIG_K_LEK_TN
	before insert
	on K_LEK
	for each row
BEGIN
  :NEW.id_pozycja_karty:=seq_k_lek.nextval;
END;