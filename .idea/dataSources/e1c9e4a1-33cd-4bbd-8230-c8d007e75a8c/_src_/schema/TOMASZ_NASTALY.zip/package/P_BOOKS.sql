create PACKAGE p_books
AS
PROCEDURE dodaj(p_isbn books.isbn%type,p_title books.title%type, p_pubdate BOOKS.PUBDATE%type, p_pubid books.pubid%type, p_cost books.cost%type, p_retail books.retail%type, p_category books.category%type);
PROCEDURE usun(p_isbn books.isbn%type);
END;