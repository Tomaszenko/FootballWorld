create PACKAGE pakiet_4_2
AS
  g_liczba_zamowien orderitems.quantity%type;
  
  PROCEDURE addCustomer(p_customer# customers.customer#%type,
  p_lastname customers.lastname%type,p_firstname customers.firstname%type,
  p_address customers.address%type,p_city customers.city%type,
  p_state customers.state%type,p_zip customers.zip%type,
  p_referred customers.referred%type);
  
  FUNCTION howManyOrders(p_customer# orders.customer#%type)
  RETURN number;
  
  FUNCTION howManyPending
  RETURN number;

END pakiet_4_2;