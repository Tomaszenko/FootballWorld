create PACKAGE BODY pakiet2
AS
  PROCEDURE addCustomer(p_customer# customers.customer#%type,p_lastname customers.last_name%type,p_firstname customers.firstname%type,p_address customers.address%type,p_city customers.city%type,p_state customers.state%type,p_zip customers.zip%type,p_referred customers.referred%type)
  IS
  BEGIN
    INSERT INTO customers VALUES(p_customer#,p_lastname,p_firstname,p_address,p_city,p_state,p_zip,p_referred);
  END;
  
  FUNCTION getNumOrders(p_customerid orders.customer#%type)
  RETURN number
  IS
    v_result number;
  BEGIN
    SELECT COUNT(order#) INTO v_result
    FROM orders
    WHERE customer#=p_customerid;
  END;
  
  FUNCTION getNumPendingOrdersFromToday
  RETURN number
  IS 
    v_result number;
  BEGIN
    SELECT COUNT(order#) INTO v_result
    FROM orders
    WHERE orderdate=sysdate AND shipdate IS NULL;
  END;
END;