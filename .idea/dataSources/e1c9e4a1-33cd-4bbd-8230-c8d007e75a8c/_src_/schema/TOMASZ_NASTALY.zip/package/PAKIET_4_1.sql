create PACKAGE pakiet_4_1
AS
  PROCEDURE addBook(p_isbn books.isbn%type,p_title books.title%type,
  p_pubdate books.pubdate%type,p_pubid books.pubid%type,p_cost books.cost%type,
  p_retail books.retail%type,p_category books.category%type);
  
  PROCEDURE removeBook(p_isbn books.isbn%type);
END;