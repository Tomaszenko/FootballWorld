create PACKAGE bookmgmt
AS
  PROCEDURE dodaj_ksiazke(p_isbn books.isbn%TYPE,p_title books.title%type,p_pubdate books.pubdate%TYPE,p_pubid BOOKS.PUBID%TYPE,p_cost BOOKS.COST%TYPE,p_retail BOOKS.RETAIL%TYPE,p_category BOOKS.CATEGORY%TYPE);
  PROCEDURE usun_ksiazke(p_isbn books.isbn%TYPE);
END bookmgmt;