create PACKAGE BODY p_books
AS
  PROCEDURE dodaj(p_isbn books.isbn%type,p_title books.title%type, p_pubdate BOOKS.PUBDATE%type, p_pubid books.pubid%type, p_cost books.cost%type, p_retail books.retail%type, p_category books.category%type)
  IS
  BEGIN
    INSERT INTO books VALUES(p_isbn,p_title,p_pubdate,p_pubid,p_cost,p_retail,p_category);
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX
      THEN DBMS_OUTPUT.put_line(SQLERRM(SQLCODE));  
      WHEN INVALID_NUMBER
      THEN DBMS_OUTPUT.put_line(SQLERRM(SQLCODE));
      WHEN OTHERS
      THEN DBMS_OUTPUT.put_line(SQLERRM(SQLCODE));
  END;
  PROCEDURE usun(p_isbn books.isbn%type)
  IS
    powiazane EXCEPTION;
    pragma exception_init(powiazane,-2292);
  BEGIN
    DELETE FROM books
    WHERE isbn=p_isbn;
    EXCEPTION
      WHEN powiazane THEN
      DBMS_OUTPUT.put_line('Nie możesz usunąć książki, istnieją powiązane rekordy');
      DBMS_OUTPUT.put_line(SQLERRM(SQLCODE));
      WHEN others THEN
      DBMS_OUTPUT.put_line(SQLERRM(SQLCODE));
  END;
END;