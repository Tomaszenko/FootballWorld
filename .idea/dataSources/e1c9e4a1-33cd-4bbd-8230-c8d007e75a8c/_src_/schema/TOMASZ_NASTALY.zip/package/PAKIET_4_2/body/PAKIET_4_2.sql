create PACKAGE BODY pakiet_4_2
AS
  PROCEDURE addCustomer(p_customer# customers.customer#%type,
  p_lastname customers.lastname%type,p_firstname customers.firstname%type,
  p_address customers.address%type,p_city customers.city%type,
  p_state customers.state%type,p_zip customers.zip%type,
  p_referred customers.referred%type)
  AS
  BEGIN
    INSERT INTO customers VALUES(p_customer#,p_lastname,p_firstname,p_address,p_city,p_state,p_zip,p_referred);
  END addCustomer;
  
  FUNCTION howManyOrders(p_customer# orders.customer#%type)
  RETURN number
  AS
    v_result number;
  BEGIN
    SELECT COUNT(order#) INTO v_result
    FROM orders
    WHERE customer#=p_customer#;
    
    RETURN v_result;
    
    EXCEPTION 
    WHEN NO_DATA_FOUND
    THEN dbms_output.put_line('Nie ma klienta o zadanym identyfikatorze');
          RETURN 0;
  END howManyOrders;
  
  FUNCTION howManyPending
  RETURN number
  AS
    v_result number;
  BEGIN
    dbms_output.put_line('Chlam');
    
    SELECT COUNT(order#) INTO v_result
    FROM orders
    WHERE TO_CHAR(orderdate,'YYYY-MM-DD')=TO_CHAR(sysdate,'YYYY-MM-DD')
      AND shipdate IS NULL;
    
    RETURN v_result;
  END;
END pakiet_4_2;