create PACKAGE BODY bookmgmt
AS
  PROCEDURE dodaj_ksiazke(p_isbn books.isbn%TYPE,p_title books.title%type,p_pubdate books.pubdate%TYPE,p_pubid BOOKS.PUBID%TYPE,p_cost BOOKS.COST%TYPE,p_retail BOOKS.RETAIL%TYPE,p_category BOOKS.CATEGORY%TYPE)
  IS
  BEGIN
    INSERT INTO books VALUES(p_isbn,p_title,p_pubdate,p_pubid,p_cost,p_retail,p_category);
    EXCEPTION 
    WHEN DUP_VAL_ON_INDEX THEN dbms_output.put_line('Próba wstawienia duplikatu klucza glownego');
    WHEN VALUE_ERROR THEN dbms_output.put_line('Wstawiane dane są nieprawidlowe');
  END dodaj_ksiazke;

  PROCEDURE usun_ksiazke(p_isbn books.isbn%TYPE)
  IS
    integrity_violation EXCEPTION;
    PRAGMA EXCEPTION_INIT(integrity_violation,-2292);
  BEGIN
    DELETE FROM books WHERE isbn=p_isbn;
    EXCEPTION
    WHEN integrity_violation THEN dbms_output.put_line('Próba usunięcia rekordu do którego istnieją odwolania');
  END usun_ksiazke;

BEGIN
  NULL;
END;