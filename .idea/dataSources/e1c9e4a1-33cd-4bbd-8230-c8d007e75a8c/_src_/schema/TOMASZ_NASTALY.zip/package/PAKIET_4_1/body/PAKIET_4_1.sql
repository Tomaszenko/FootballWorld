create PACKAGE BODY pakiet_4_1
AS
  PROCEDURE addBook(p_isbn books.isbn%type,p_title books.title%type,
  p_pubdate books.pubdate%type,p_pubid books.pubid%type,p_cost books.cost%type,
  p_retail books.retail%type,p_category books.category%type)
  AS
    v_code number;
    v_msg varchar2(512);
  BEGIN
    INSERT INTO books VALUES(p_isbn,p_title,p_pubdate,p_pubid,p_cost,p_retail,p_category);
    EXCEPTION
      WHEN DUP_VAL_ON_INDEX
      THEN 
        dbms_output.put_line('Próba wstawienia duplikatu klucza glownego');
      WHEN VALUE_ERROR OR INVALID_NUMBER
      THEN 
        dbms_output.put_line('Wstawiane dane są niepoprawne');
      WHEN OTHERS
      THEN 
        v_code:=SQLCODE;
        v_msg:=SQLERRM;
        dbms_output.put_line(TO_CHAR(v_code)||': '||v_msg);
  END addBook;

  PROCEDURE removeBook(p_isbn books.isbn%type)
  AS
    integrity_violation exception;
    pragma exception_init(integrity_violation,-2292);
    v_code number;
    v_msg varchar2(512);
  BEGIN
    DELETE FROM books
    WHERE isbn=p_isbn;
    
    EXCEPTION
    WHEN integrity_violation
    THEN dbms_output.put_line('Usunięcie spowodowaloby utracenie integralności!');
    WHEN no_data_found
    THEN dbms_output.put_line('Nie ma takiego numeru');
    WHEN OTHERS
    THEN 
      v_code:=SQLCODE;
      v_msg:=SQLERRM;
      dbms_output.put_line(TO_CHAR(v_code)||': '||v_msg);
  END;
END;